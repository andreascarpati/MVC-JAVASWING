package progetto20;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

// ===== MODEL =====
class User  {
    private ArrayList<String> Users = new ArrayList<>();
   

    public User() {
    	
    	Users.add("Andrea Scarpati");
        
    }

    public ArrayList<String> getUser() {
        return Users;
    }
    public String getfinishUser() {
        return Users.get(Users.size() - 1);
    }	
    public void addUser(String user) {
		Users.add(user);
	}

   public String toString() {
	   String result = "";
	   for (String user : Users) {
		   result += user + "\n";
	   }
	   return result;
   }
}
