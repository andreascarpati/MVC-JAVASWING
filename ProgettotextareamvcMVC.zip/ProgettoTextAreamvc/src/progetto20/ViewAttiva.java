package progetto20;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.util.Observable;
import java.util.Observer;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class ViewAttiva extends JFrame {
	private JPanel pannelcontent= new JPanel();
	private JPanel pannelinput= new JPanel();
	private JPanel panneloutput= new JPanel();
	private JPanel pannelcontr= new JPanel();
	private JTextField tnome=new JTextField(10);
	private JTextField tcognome=new JTextField(10);
	private JLabel lblnome=new JLabel("Nome",JLabel.RIGHT);
	private JLabel lblcognome=new JLabel("cOGNOME",JLabel.RIGHT);
	private JTextArea area = new JTextArea();
	private JButton btok=new JButton("ok"); 
	private JButton btAnnul=new JButton("Annulla");
	ViewAttiva( ){
		super("Esempio MVC Attivo");
	//Pannelloinput
		pannelcontent.setLayout(new BoxLayout(pannelcontent, BoxLayout.Y_AXIS));
	
	JPanel listPane = new JPanel();
	
	
	
 	
	pannelinput.setLayout(new FlowLayout(FlowLayout.CENTER,1,4));
	
	pannelinput.add(lblnome);
	pannelinput.add(tnome);
	pannelinput.add(lblcognome);
	pannelinput.add(tcognome);
	 
	panneloutput.setLayout(new FlowLayout(FlowLayout.CENTER,1,1));
    //pannello centrale
    panneloutput.add(area);

    //pannello controlo
    pannelcontr.setLayout(new FlowLayout(FlowLayout.CENTER,1,2));
    pannelcontr.add(btok);
       btok.addActionListener(new Controller(tnome, tcognome, area));
			pannelcontent.setLayout(new BorderLayout());
			pannelcontent.add(pannelinput, BorderLayout.NORTH);
			pannelcontent.add(panneloutput, BorderLayout.CENTER);
			pannelcontent.add(pannelcontr, BorderLayout.SOUTH);
		        	
		   
       
        
        add(pannelcontent);
        setBounds(500, 200, 500, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

}