package progetto20;

import java.util.Observer;

//===== MAIN =====
public class MainMVC {
 public static void main(String[] args) {
	 Controller controller=new Controller();
	 User model=new User();
   new ViewAttiva( );
 }
}
