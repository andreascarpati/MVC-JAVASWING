package progetto20;

import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ColorModel;

import javax.swing.JTextArea;
import javax.swing.JTextField;

//===== CONTROLLER =====
public class Controller implements ActionListener {
private	JTextField tnome;
	private JTextField tcognome;
	private JTextArea area;
 private User model=new User();
private ViewAttiva v;
public Controller() {
	
	// TODO Auto-generated constructor stub
}
public Controller(JTextField tnome,JTextField tcognome,JTextArea area){
	this.tnome=tnome;
	this.tcognome=tcognome;
	this.area=area;
}


 

 





 @Override
 public void actionPerformed(ActionEvent e) {
	 if(e.getActionCommand().equals("ok")) {
	 
	  model.addUser(tnome.getText()+" "+tcognome.getText());
	  String result=model.getfinishUser();
	  area.append(result+"\n");
	 }
 }
}
